from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

WORKTREE = Path('/workspace/scratch/f5d98b1de49e/SharpForge-p9-runtime-baseline')
ARTIFACTS = WORKTREE / 'artifacts/project9-resume'
OUT = ARTIFACTS / 'publication-boolean/evidence-tree/evidence/project9/boolean-qualified'
OUT.mkdir(parents=True, exist_ok=True)
selected = {}

for source in sorted(ARTIFACTS.glob('boolean-*')):
    if source.name.startswith('boolean-a00-') or source.name == 'boolean-pr-body-template.md':
        continue
    if source.is_file():
        selected['qualification/' + source.name] = source
    elif source.name in ['boolean-controls-abba', 'boolean-optimized-controls-abba',
                         'boolean-packed-artifacts', 'boolean-native-build']:
        for file in sorted(source.rglob('*')):
            if file.is_file():
                selected['qualification/' + file.relative_to(ARTIFACTS).as_posix()] = file
for name in ['run-boolean-benchmarks.py', 'run-boolean-optimized-benchmarks.py',
             'pack-boolean-artifacts.py', 'build-boolean-evidence.py']:
    selected['qualification/' + name] = ARTIFACTS / name
native = WORKTREE / 'packages/bcl-core/reference/boolean-string-fields'
for name in ['Program.cs', 'BooleanStringFieldsReference.csproj', 'README.md', '.gitignore']:
    selected['native/' + name] = native / name
selected['native/boolean-string-fields-net10.json'] = native.parent / 'boolean-string-fields-net10.json'

manifest = {'publishedProductCommit': 'd6c6eb24eae3a7116b4bb5497c68b40b90aa3d2c',
            'measuredProductCommit': 'af29812a6b0ca0184a79cc6bcddd01bf0a02fb6a',
            'productTree': 'd934a12e448fc825ad49a535ced67a801e98e57c',
            'baseline': 'af5450dacbdc2734432b13dffa63efb10eb93145',
            'scope': 'Product qualification only; A00 contracts, task claim and current-main integration remain pending.',
            'history': 'The initial bcd188 performance cohort is rejected. boolean-final-* records precede the corrective af298 batch. Only optimized records and the d6 published replay describe the final product tree.',
            'files': []}
for path, source in selected.items():
    data = source.read_bytes()
    manifest['files'].append({'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest['fileCount'] = len(selected)
manifest['totalUncompressedBytes'] = sum(x['bytes'] for x in manifest['files'])
manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'manifest.json').write_bytes(manifest_data)

archive = OUT / 'qualification.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            contents = {'manifest.json': manifest_data}
            contents.update({path: source.read_bytes() for path, source in selected.items()})
            for path, data in sorted(contents.items()):
                info = tarfile.TarInfo('boolean-qualified/' + path)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = {member.name: member for member in tar.getmembers()}
    assert len(members) == len(selected) + 1
    for row in manifest['files']:
        data = tar.extractfile(members['boolean-qualified/' + row['path']]).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

direct = ['boolean-publication.json', 'boolean-optimized-qualification.json',
          'boolean-published-replay.json', 'boolean-published-replay-tests.tap',
          'boolean-optimized-controls-summary.json', 'boolean-optimized-performance-review.md',
          'boolean-optimized-performance-review.json', 'boolean-final-artifact-review.md',
          'boolean-final-artifact-review.json', 'boolean-final-asset-provenance.json']
for name in direct:
    shutil.copyfile(ARTIFACTS / name, OUT / name)
sizes = json.loads((ARTIFACTS / 'boolean-artifact-qualification.json').read_text())
(OUT / 'artifact-summary.json').write_text(json.dumps({key: sizes[key] for key in
    ['baseline', 'candidate', 'complete', 'packageComparison', 'browser']}, indent=2) + '\n')
index = {'archive': archive.name, 'bytes': archive.stat().st_size,
         'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
         'manifestSha256': hashlib.sha256(manifest_data).hexdigest(),
         'filesInArchive': len(selected) + 1, 'payloadUncompressedBytes': manifest['totalUncompressedBytes']}
(OUT / 'archive.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps(index, indent=2))

from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/f5d98b1de49e')
ROOTS = {'baseline': ROOT / 'SharpForge-p9-boolean-control',
         'candidate': ROOT / 'SharpForge-p9-runtime-baseline'}
REVISIONS = {'baseline': 'af5450dacbdc2734432b13dffa63efb10eb93145',
             'candidate': 'af29812a6b0ca0184a79cc6bcddd01bf0a02fb6a'}
OUT = ROOTS['candidate'] / 'artifacts/project9-resume/boolean-packed-artifacts'
PACKAGES = ['bcl-core', 'bytecode', 'cil', 'compiler', 'framework', 'runtime']
OUT.mkdir(exist_ok=True)
record = {'baseline': REVISIONS['baseline'], 'candidate': REVISIONS['candidate'],
          'commands': [], 'packages': [], 'browser': {}}
record_path = OUT.parent / 'boolean-artifact-qualification.json'

def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')

for side, root in ROOTS.items():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == REVISIONS[side]
    target = OUT / side
    target.mkdir(exist_ok=True)
    for name in PACKAGES:
        argv = ['npm', 'pack', './packages/' + name, '--ignore-scripts', '--json',
                '--pack-destination', str(target)]
        row = {'side': side, 'package': name, 'argv': argv, 'cwd': str(root),
               'revision': REVISIONS[side], 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        record['commands'].append(row)
        save()
        result = subprocess.run(argv, cwd=root, text=True, capture_output=True)
        (target / (name + '.stdout.json')).write_text(result.stdout)
        (target / (name + '.stderr.log')).write_text(result.stderr)
        row['exitCode'] = result.returncode
        row['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        assert result.returncode == 0, result.stderr
        report = json.loads(result.stdout)[0]
        tgz = target / report['filename']
        entries = []
        with tarfile.open(tgz, 'r:gz') as tar:
            for member in tar.getmembers():
                assert member.isfile() and member.name.startswith('package/')
                relative = member.name.removeprefix('package/')
                source = root / 'packages' / name / relative
                if not source.is_file() and relative == 'LICENSE':
                    source = root / 'LICENSE'
                data = tar.extractfile(member).read()
                source_bytes = source.read_bytes()
                assert data == source_bytes, (side, name, relative, 'packed bytes differ from source')
                git_path = source.relative_to(root).as_posix()
                blob = subprocess.check_output(['git', 'rev-parse', REVISIONS[side] + ':' + git_path], cwd=root, text=True).strip()
                assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == blob
                entries.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                                'sourcePath': git_path, 'sourceGitBlob': blob})
        assert len(entries) == report['entryCount']
        assert sum(x['bytes'] for x in entries) == report['unpackedSize']
        assert tgz.stat().st_size == report['size']
        record['packages'].append({'side': side, 'package': name, 'revision': REVISIONS[side],
                                   'tarball': tgz.relative_to(OUT.parent).as_posix(),
                                   'sha256': hashlib.sha256(tgz.read_bytes()).hexdigest(),
                                   'size': report['size'], 'unpackedSize': report['unpackedSize'],
                                   'fileCount': len(entries), 'allFilesMatchGit': True, 'files': entries})
        save()
        print(side, name, report['size'], report['unpackedSize'], len(entries), flush=True)
    files = []
    for path in sorted((root / 'dist').rglob('*')):
        if path.is_file():
            data = path.read_bytes()
            files.append({'path': path.relative_to(root / 'dist').as_posix(), 'bytes': len(data),
                          'sha256': hashlib.sha256(data).hexdigest()})
    assert files
    asset = {'revision': REVISIONS[side], 'files': files, 'totalBytes': sum(x['bytes'] for x in files), 'fileCount': len(files)}
    if side == 'baseline':
        assert asset == json.loads((OUT.parent / 'boolean-baseline-assets.json').read_text())
        asset_path = OUT.parent / 'boolean-baseline-assets.json'
    else:
        asset_path = OUT.parent / 'boolean-candidate-final-assets.json'
        asset_path.write_text(json.dumps(asset, indent=2) + '\n')
    record['browser'][side] = {'manifest': asset_path.name, 'sha256': hashlib.sha256(asset_path.read_bytes()).hexdigest(),
                               'totalBytes': asset['totalBytes'], 'fileCount': asset['fileCount']}
    save()

record['packageComparison'] = []
for name in PACKAGES:
    rows = {x['side']: x for x in record['packages'] if x['package'] == name}
    a, b = rows['baseline'], rows['candidate']
    record['packageComparison'].append({'package': name, 'baselineBytes': a['size'], 'candidateBytes': b['size'],
                                        'deltaBytes': b['size'] - a['size'], 'percent': 100 * (b['size'] / a['size'] - 1),
                                        'baselineUnpackedBytes': a['unpackedSize'], 'candidateUnpackedBytes': b['unpackedSize'],
                                        'unpackedDeltaBytes': b['unpackedSize'] - a['unpackedSize'],
                                        'unpackedPercent': 100 * (b['unpackedSize'] / a['unpackedSize'] - 1)})
a, b = record['browser']['baseline'], record['browser']['candidate']
record['browser']['deltaBytes'] = b['totalBytes'] - a['totalBytes']
record['browser']['percent'] = 100 * (b['totalBytes'] / a['totalBytes'] - 1)
record['complete'] = True
save()
print(json.dumps({'packages': record['packageComparison'], 'browser': record['browser']}, indent=2), flush=True)

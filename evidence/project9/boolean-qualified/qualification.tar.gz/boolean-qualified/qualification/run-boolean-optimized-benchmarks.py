from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/f5d98b1de49e')
BASE = ROOT / 'SharpForge-p9-boolean-control'
CANDIDATE = ROOT / 'SharpForge-p9-runtime-baseline'
OUT = CANDIDATE / 'artifacts/project9-resume/boolean-optimized-controls-abba'
OUT.mkdir(exist_ok=True)
RUNNER = Path('scripts/benchmarks/a07-boolean-string-fields.mjs')
SHA = 'ba0202edda201ad0755f16e4e30811c90e8b9b5027b940b08819b63ae207c14e'
REVISIONS = {
    BASE: 'af5450dacbdc2734432b13dffa63efb10eb93145',
    CANDIDATE: 'af29812a6b0ca0184a79cc6bcddd01bf0a02fb6a',
}
for root, revision in REVISIONS.items():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == revision
    assert hashlib.sha256((root / RUNNER).read_bytes()).hexdigest() == SHA

report = {'runnerSha256': SHA, 'baseline': REVISIONS[BASE], 'candidate': REVISIONS[CANDIDATE],
          'iterations': 5000, 'warmups': 5, 'retainedSamplesPerProcess': 9, 'commands': []}
record = OUT.parent / 'boolean-optimized-benchmark-execution.json'

def run(root, label, engine, case, group):
    argv = ['node', '--expose-gc', str(RUNNER), '5000', label, '--engine', engine, '--case', case]
    name = f'{engine}-{case}-{label}'
    row = {'argv': argv, 'cwd': str(root), 'revision': REVISIONS[root], 'group': group,
           'engine': engine, 'case': case, 'label': label,
           'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'stdout': str(OUT / (name + '.json')), 'stderr': str(OUT / (name + '.log'))}
    report['commands'].append(row)
    record.write_text(json.dumps(report, indent=2) + '\n')
    with Path(row['stdout']).open('w') as stdout, Path(row['stderr']).open('w') as stderr:
        result = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr)
    row['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    row['exitCode'] = result.returncode
    row['stdoutSha256'] = hashlib.sha256(Path(row['stdout']).read_bytes()).hexdigest()
    record.write_text(json.dumps(report, indent=2) + '\n')
    if result.returncode:
        print(Path(row['stderr']).read_text(), flush=True)
        raise SystemExit(result.returncode)
    data = json.loads(Path(row['stdout']).read_text())
    assert data['revision'] == REVISIONS[root] and data['runnerSha256'] == SHA
    assert data['isolatedWorkload'] and data['gcAvailable']
    print(json.dumps({'completed': name, 'revision': REVISIONS[root]}), flush=True)

controls = [(engine, case) for engine in ['source', 'cil']
            for case in ['literalCold', 'literalLoop', 'staticStringLoop', 'readonlyScalarLoop']]
controls.extend([('cil', 'stringConstructorLoop'), ('cil', 'readonlyScalarFieldLoop')])
for engine, case in controls:
    for root, label in [(BASE, 'A1'), (CANDIDATE, 'B1'), (CANDIDATE, 'B2'), (BASE, 'A2')]:
        run(root, label, engine, case, 'existing-control')
report['allExistingControlsFinishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record.write_text(json.dumps(report, indent=2) + '\n')
for engine in ['source', 'cil']:
    run(CANDIDATE, 'new', engine, 'readonlyStringLoop', 'new-field')
report['complete'] = True
record.write_text(json.dumps(report, indent=2) + '\n')

import {readFileSync, writeFileSync} from 'node:fs';
import {resolve, relative, dirname} from 'node:path';
import {SourceTextModule} from 'node:vm';
import {builtinModules, createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd(), destination=process.argv[2];
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const tracked=new Set(execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0'));
const pending=['tests/a05-cil-generic-metadata-names.test.js','tests/a05-02-generic-calls.test.js','tests/a05-02-generic-dispatch.test.js','tests/a05-type-tables.test.js','tests/a05-cil-async-generics.test.js','tests/fixtures/cil-async/capture-generic.mjs','tests/fixtures/cil-async/generic-runtime.mjs'];
const records=new Map(), externals=new Set(), errors=[];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
while(pending.length) {
 const path=pending.pop();if(records.has(path))continue;
 const bytes=readFileSync(resolve(root,path)),source=bytes.toString('utf8');
 const parsed=new SourceTextModule(source,{identifier:path});
 const imports=[...parsed.dependencySpecifiers,...[...source.matchAll(/\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/g)].map(match=>match[1])];
 const dependencies=[];
 for(const specifier of imports) {
  if(builtinModules.includes(specifier)||specifier.startsWith('node:')){externals.add(specifier);continue;}
  try {
   const target=specifier.startsWith('.')?resolve(root,dirname(path),specifier):createRequire(pathToFileURL(resolve(root,path))).resolve(specifier);
   const local=relative(root,target);if(local.startsWith('..'))throw new Error('resolved outside tested tree: '+target);
   dependencies.push(local);if(/\.[cm]?js$/.test(local))pending.push(local);
  } catch(error){errors.push({path,specifier,error:error.message});}
 }
 const record={path,sha256:hash(bytes),tracked:tracked.has(path),dependencies:[...new Set(dependencies)].sort()};
 if(record.tracked){const blob=execFileSync('git',['show',head+':'+path]);record.matchesHead=hash(blob)===record.sha256;}
 records.set(path,record);
}
const output={head,kind:'static ESM with literal dynamic-import inventory',modules:[...records.values()].sort((a,b)=>a.path.localeCompare(b.path)),externals:[...externals].sort(),errors,
 trackedDiff:execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim(),
 preservedUntracked:execFileSync('git',['ls-files','--others','--exclude-standard'],{encoding:'utf8'}).trim().split('\n')};
writeFileSync(destination,JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({head,modules:records.size,untracked:[...records.values()].filter(x=>!x.tracked).map(x=>x.path),changed:[...records.values()].filter(x=>x.tracked&&!x.matchesHead).map(x=>x.path),errors,sha256:hash(readFileSync(destination))},null,2));

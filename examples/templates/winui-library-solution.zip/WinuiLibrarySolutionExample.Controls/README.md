# WinuiLibrarySolutionExample.Controls

Open this project in SharpForge and Run. This is a code-first WinUI **web profile**, not a Windows App SDK project. Components expose a real WinUI-shaped control through `.View`. Native WinUI base-class inheritance, XAML, dependency properties and control templates are not supplied by this template. No Windows App SDK NuGet dependency is implied.

This project is a library; add a project reference from an application.

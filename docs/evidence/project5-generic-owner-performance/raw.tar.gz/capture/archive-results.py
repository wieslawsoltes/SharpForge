from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile

ROOT = Path('/workspace/scratch/1692a10afba9')
PACKET = Path(__file__).resolve().parent
REPOSITORY = ROOT / 'p5-inline-arrays'
NAME, DESTINATION = sys.argv[1], Path(sys.argv[2])
PLAN = json.loads((PACKET / 'plan.json').read_text())
REPORT = json.loads((PACKET / NAME / 'performance.json').read_text())
BEFORE = json.loads((PACKET / NAME / 'before.json').read_text())
OUTER = json.loads((PACKET / NAME / 'outer-result.json').read_text())
DESTINATION.mkdir(parents=True, exist_ok=True)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPOSITORY)

contents = {}
for path in [PACKET / 'plan.json', PACKET / 'run.py', PACKET / 'paired.py', Path(__file__).resolve(),
             *sorted((PACKET / NAME).iterdir())]:
    if path.is_file():
        contents['capture/' + str(path.relative_to(PACKET))] = path.read_bytes()

# Reconstruct the exact qualified exports from Git and verify every byte against the
# already-retained before/after inventory. This is archival work, not another run.
runner_paths = {item['path'] for item in REPORT['runnerFiles']}
for label, source in REPORT['sources'].items():
    paths = [item['path'] for item in source['files'] if item['path'] not in runner_paths]
    archive = git('archive', '--format=tar', source['commit'], *paths)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        source_files = {item.name: tar.extractfile(item).read() for item in tar if item.isfile()}
    for item in source['files']:
        path = item['path']
        data = git('show', REPORT['runnerRevision'] + ':' + path) if path in runner_paths else source_files[path]
        assert len(data) == item['bytes'] and digest(data) == item['sha256'], (label, path)
        contents['qualified-source/' + label + '/' + path] = data

for name, identity in BEFORE['capture'].items():
    data = (Path(PLAN['jobs'][NAME]['capture']) / name).read_bytes()
    assert len(data) == identity['bytes'] and digest(data) == identity['sha256'], name
    contents['retained-native-input/' + name] = data

inventory = [{'path': path, 'bytes': len(data), 'sha256': digest(data)} for path, data in sorted(contents.items())]
raw_path = DESTINATION / 'raw.tar.gz'
with raw_path.open('xb') as file:
    with gzip.GzipFile(fileobj=file, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path, data in sorted(contents.items()):
                info = tarfile.TarInfo(path)
                info.size, info.mtime, info.mode = len(data), 0, 0o644
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(raw_path, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(contents)
    for item in tar:
        assert tar.extractfile(item).read() == contents[item.name], item.name

comparisons, breaches = [], []
for case in REPORT['comparisons']:
    metrics = {}
    for metric, values in case['metrics'].items():
        rows = {}
        for statistic in ['median', 'p95']:
            baseline, candidate = values['baseline'][statistic], values['candidate'][statistic]
            percent = (candidate / baseline - 1) * 100 if baseline else None
            rows[statistic] = {'baseline': baseline, 'candidate': candidate,
                               'absoluteChange': candidate - baseline, 'percentChange': percent}
            if metric.endswith('Ms') and percent is not None and percent > 5:
                breaches.append({'case': case['name'], 'metric': metric, 'statistic': statistic, **rows[statistic]})
        metrics[metric] = rows
    comparisons.append({'name': case['name'], 'metrics': metrics})

assert OUTER['exitCode'] == 0 and OUTER['captureUnchanged']
assert REPORT['stage'] == 'finished' and len(REPORT['runs']) == 4
for run in REPORT['runs']:
    assert run['exitCode'] == 0 and not run.get('failure')
    assert run['result']['warmups'] == 80 and run['result']['samples'] == 24

justification = {
    'generic-names': 'Accept the recorded cost to preserve complete generated metadata names and use authoritative GenericParam owner arity. The focused controls establish that the earlier parser/arity path rejects valid generated owners. One bounded inspector inventory replaces repeated discovery; no per-instruction mechanism or broader aggregate storage was added.',
    'async-substitution': 'Accept the recorded cost to substitute async method and owner contracts exactly once. The actual baseline rejects GenericMethod Debug/Release; GenericOwner Debug/Release already execute and therefore remain comparative workloads. Caller VAR/MVAR identities must not be recursively rewritten into the substituted argument itself.'
}[NAME]
record = {
    'schemaVersion': 1, 'job': NAME, 'baseline': REPORT['baseline'], 'candidate': REPORT['candidate'],
    'runnerRevision': REPORT['runnerRevision'], 'caseSet': REPORT['caseSet'],
    'measuredAt': REPORT['startedUtc'], 'environment': REPORT['environment'],
    'engine': REPORT['runs'][0]['result']['engine'], 'node': REPORT['runs'][0]['result']['node'],
    'design': {'order': REPORT['order'], 'warmupsPerRound': 80, 'samplesPerRound': 24,
               'samplesPerVersionPerMeasuredCase': 48, 'roundTimeoutSeconds': 180,
               'normalMachineLimiter': True, 'sharedHost': True, 'reruns': 0,
               'sourceFilesVerifiedBeforeAndAfterEveryRound': True,
               'aliasScope': 'Eleven workspace aliases were checked at construction; no separate post-round alias audit is claimed.',
               'nativeInputsUnchanged': True, 'nativeRegeneration': False},
    'duration': OUTER, 'comparisons': comparisons, 'caseSummaries': REPORT['summary'],
    'budgetBreaches': breaches,
    'disposition': {'result': 'accepted quantified correctness cost; not a performance pass',
                    'reviewer': 'Project #5 implementation owner (root agent)',
                    'authorization': 'User-directed continuation and completion of Project #5; CONTRIBUTING section 4 allows explicitly justified correctness cost.',
                    'justification': justification,
                    'scope': 'Accept every listed median/p95 breach from this actual paired capture. No causal attribution to a quiet host, no threshold adjustment, and no noise rerun.'},
    'measurementLimits': ['Managed allocations and managed charged bytes are recorded; JavaScript allocations and heap retention were not measured.',
                          'Export source bytes are provenance, not a build-output-size measurement.',
                          'Comparative ratios require both revisions to execute and match expected output. Rejected baselines have candidate absolute results only.',
                          'These are exact retained-source measurements; integrated publication correctness checks are recorded separately.'],
    'archive': {'path': raw_path.name, 'bytes': raw_path.stat().st_size,
                'sha256': digest(raw_path.read_bytes()), 'entries': inventory,
                'qualifiedSourceSnapshots': 'All package and runner files reconstructed from Git match the actual qualified inventories byte for byte.'}
}
with (DESTINATION / 'timing-disposition.json').open('x') as file:
    json.dump(record, file, indent=2)
    file.write('\n')

lines = ['# ' + ('Generated generic owners' if NAME == 'generic-names' else 'Generic async substitution') + ' performance', '',
         'The implementation owner accepts the quantified correctness cost below. This capture is not a performance-budget pass.', '',
         justification, '', '## Method', '',
         'One balanced A/B/B/A capture used 80 independent warmups and 24 samples per round, giving 48 samples per version and measured case. '
         'The normal machine limiter ran on a shared host. Every exported source file was checked before and after each round. '
         'Native PE bytes and recorded output remained unchanged; no compiler or CLR output was regenerated.', '',
         'Baseline: ' + REPORT['baseline'] + '. Candidate: ' + REPORT['candidate'] + '. Runner: ' + REPORT['runnerRevision'] + '.', '',
         'The archived launcher records the exact command and all three .NET pins. The raw archive also includes the original logs, '
         'all samples, retained native inputs and byte-verified complete package source snapshots for both revisions.', '',
         '## Comparable total time', '',
         '| Case | Median before (ms) | Median after (ms) | Change | p95 before (ms) | p95 after (ms) |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
for case in comparisons:
    m, p = case['metrics']['totalMs']['median'], case['metrics']['totalMs']['p95']
    lines.append('| ' + case['name'] + f" | {m['baseline']:.6f} | {m['candidate']:.6f} | {m['percentChange']:+.3f}% | {p['baseline']:.6f} | {p['candidate']:.6f} |")
lines.extend(['', '## Every timing breach above 5%', '',
              '| Case | Metric | Statistic | Before (ms) | After (ms) | Absolute change (ms) | Change |',
              '| --- | --- | --- | ---: | ---: | ---: | ---: |'])
for row in breaches:
    lines.append(f"| {row['case']} | {row['metric']} | {row['statistic']} | {row['baseline']:.6f} | {row['candidate']:.6f} | {row['absoluteChange']:+.6f} | {row['percentChange']:+.3f}% |")
lines.extend(['', 'The disposition accepts all listed breaches for the stated correctness fix. It does not infer that variation is noise or claim a speedup for a previously rejected program.', '',
              'Managed allocation counts and charged bytes remain identical for every comparable case. JavaScript allocations and build output size were not measured. '
              'The JSON retains all admission/execution/total median and p95 values, candidate-only absolute measurements, process durations and archive hashes.', ''])
with (DESTINATION / 'README.md').open('x') as file:
    file.write('\n'.join(lines))
print(json.dumps({'job': NAME, 'archiveBytes': raw_path.stat().st_size, 'archiveSha256': record['archive']['sha256'],
                  'entries': len(contents), 'breaches': len(breaches), 'destination': str(DESTINATION)}))

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/1692a10afba9')
PACKET = Path(__file__).resolve().parent
REPOSITORY = ROOT / 'p5-inline-arrays'
PLAN = json.loads((PACKET / 'plan.json').read_text())
NAME = sys.argv[1]
JOB = PLAN['jobs'][NAME]
DESTINATION = PACKET / NAME


def persist(name, value):
    with (DESTINATION / name).open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def now():
    return datetime.now(timezone.utc).isoformat()


command = ['python3', str(PACKET / 'paired.py'), 'benchmark', '--repository', str(REPOSITORY),
           '--baseline', JOB['baseline'], '--candidate', JOB['candidate'],
           '--runner-revision', PLAN['runnerRevision'], '--case-set', JOB['caseSet'],
           '--capture', JOB['capture'], '--output', str(DESTINATION / 'performance.json')]
if sys.argv[2:] == ['--child']:
    persist('child-start.json', {'time': now(), 'command': command})
    started = time.monotonic()
    result = subprocess.run(command, cwd=REPOSITORY)
    persist('child-result.json', {'finishedAt': now(), 'exitCode': result.returncode,
                                 'seconds': time.monotonic() - started})
    raise SystemExit(result.returncode)

DESTINATION.mkdir(exist_ok=False)
script = (PACKET / 'paired.py').read_bytes()
assert hashlib.sha256(script).hexdigest() == PLAN['orchestratorSha256']
identities = {}
for revision in [JOB['baseline'], JOB['candidate'], PLAN['runnerRevision']]:
    head = subprocess.check_output(['git', 'rev-parse', revision + '^{commit}'], cwd=REPOSITORY).decode().strip()
    assert head == revision
    identities[revision] = subprocess.check_output(['git', 'rev-parse', revision + '^{tree}'], cwd=REPOSITORY).decode().strip()
capture = Path(JOB['capture'])
reference = {path.name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
             for path in capture.iterdir() if path.is_file() and (path.suffix == '.dll' or path.name == 'capture.json')}
environment = dict(os.environ, **PLAN['pinEnvironment'])
outer = ['node', 'scripts/limited.js', 'python3', str(Path(__file__).resolve()), NAME, '--child']
persist('before.json', {'time': now(), 'headsAndTrees': identities, 'capture': reference,
                        'environment': PLAN['pinEnvironment'], 'command': outer,
                        'launcherSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                        'limiterSha256': hashlib.sha256((REPOSITORY / 'scripts/limited.js').read_bytes()).hexdigest()})
print(json.dumps({'phase': 'queued', 'name': NAME, 'command': outer}), flush=True)
started = time.monotonic()
with (DESTINATION / 'orchestrator.stdout.log').open('xb') as stdout, (DESTINATION / 'orchestrator.stderr.log').open('xb') as stderr:
    result = subprocess.run(outer, cwd=REPOSITORY, env=environment, stdout=stdout, stderr=stderr)
wall = time.monotonic() - started
child = json.loads((DESTINATION / 'child-result.json').read_text())
after = {path.name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
         for path in capture.iterdir() if path.is_file() and (path.suffix == '.dll' or path.name == 'capture.json')}
persist('outer-result.json', {'finishedAt': now(), 'exitCode': result.returncode, 'seconds': wall,
                              'childSeconds': child['seconds'], 'limiterAndStartupSeconds': wall - child['seconds'],
                              'captureUnchanged': reference == after})
assert reference == after
print(json.dumps({'name': NAME, 'exitCode': result.returncode, 'seconds': wall, 'child': child}), flush=True)
raise SystemExit(result.returncode)

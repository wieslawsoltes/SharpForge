import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path('/workspace/scratch/7e3d2a445c44/sf6-manifest-resources')
evidence = root.parent / 'manifest-qualification-f41f3e8'
phase = sys.argv[1]
commands = {
    'baseline': ['node', 'scripts/limited.js', 'node', '--test', 'tests/clr-resources-manifest-hash-length.test.js'],
    'capture': ['node', 'scripts/limited.js', 'node', 'packages/clr/tools/capture-manifest-resources.mjs',
                'tests/fixtures/clr-manifest-resources', str(evidence / 'native-first')],
    'focused': ['node', 'scripts/limited.js', 'node', '--test',
                'tests/clr-resources-manifest-hash-length.test.js', 'tests/clr-resources-manifest-malformed.test.js',
                'tests/clr-resources-manifest-reference.test.js', 'tests/clr-resources-manifest.test.js'],
    'benchmark': ['node', 'scripts/limited.js', 'node', 'packages/clr/tools/benchmark-manifest-resources.mjs'],
}
assert phase in commands
stdout_path = evidence / f'{phase}.stdout'
stderr_path = evidence / f'{phase}.stderr'
record_path = evidence / f'{phase}-execution.json'
assert all(not path.exists() for path in [stdout_path, stderr_path, record_path]), 'execution outputs already exist'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds')
def sources():
    paths = ['packages/clr/src/assembly.js', 'packages/clr/src/identity.js', 'packages/clr/src/index.js',
             'packages/clr/tools/capture-manifest-resources.mjs', 'packages/clr/tools/benchmark-manifest-resources.mjs',
             'tests/fixtures/clr-manifest-resources/Images.cs', 'tests/fixtures/clr-manifest-resources/Program.cs',
             'tests/clr-manifest-fixtures.js', 'scripts/limited.js', 'scripts/planning/lib/resource-limits.js']
    paths.extend(str(path.relative_to(root)) for path in sorted((root / 'packages/clr/src/resources').glob('*.js')))
    paths.extend(str(path.relative_to(root)) for path in sorted((root / 'tests').glob('clr-resources-manifest*.test.js')))
    return {name: sha(root / name) for name in paths}
packages = ['clr', 'cil', 'archive', 'bytecode', 'framework', 'bcl-core', 'bcl-collections']
manifest = []
for name in packages:
    for path in sorted((root / 'packages' / name / 'src').rglob('*')):
        if path.is_file() and path.name != 'assembly-identity-reader.js':
            manifest.append(f'{path.relative_to(root)}\0{sha(path)}\n')
env = dict(os.environ)
if phase == 'capture':
    env['SHARPFORGE_ORACLE_DOTNET'] = str(root.parent / 'dotnet-10.0.201/dotnet')
record = {
    'schemaVersion': 1, 'phase': phase, 'argv': commands[phase], 'cwd': str(root),
    'nodeExecutable': str(Path(shutil.which('node')).resolve()),
    'nodeVersion': subprocess.check_output(['node', '--version'], text=True).strip(),
    'sourceCommit': git('rev-parse', 'HEAD'), 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
    'gitStatusBefore': git('status', '--porcelain=v1'), 'trackedDiffBefore': git('diff', 'HEAD', '--stat'),
    'environment': {key: env.get(key) for key in ['CI', 'NODE_OPTIONS', 'NODE_PATH', 'SHARPFORGE_TEST_CONCURRENCY',
        'SHARPFORGE_MAX_PARALLEL_RUNS', 'SHARPFORGE_MAX_OLD_SPACE_MB', 'SHARPFORGE_ORACLE_DOTNET']},
    'platform': dict(zip(['system', 'node', 'release', 'version', 'machine'], os.uname())),
    'memoryBytes': int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                           if line.startswith('MemTotal:'))) * 1024,
    'sourceSha256': sources(), 'recorderSha256': sha(Path(__file__)),
    'packageSourceFileCount': len(manifest),
    'packageSourceManifestSha256': hashlib.sha256(''.join(manifest).encode()).hexdigest(),
    'packageTreeIds': {name: git('rev-parse', f'HEAD:packages/{name}') for name in packages},
    'packageAliases': {name: str((root / 'node_modules/@sharpforge' / name).resolve()) for name in packages if name != 'clr'},
}
fixture = root / 'tests/fixtures/clr-manifest-resources/native-manifest-resources.json'
record['fixtureSha256Before'] = sha(fixture) if fixture.exists() else None
assert not record['trackedDiffBefore'], 'refuse execution with tracked source changes'
assert all((root / 'node_modules/@sharpforge' / name).is_dir() for name in packages if name != 'clr')
if phase == 'capture':
    assert not fixture.exists(), 'first native fixture must be absent'
record['startedUtc'] = utc()
start = time.monotonic()
with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
    result = subprocess.run(commands[phase], cwd=root, env=env, stdout=stdout, stderr=stderr, check=False)
record['completedUtc'] = utc()
record['durationSeconds'] = time.monotonic() - start
record['exitCode'] = result.returncode
record['sourceCommitAfter'] = git('rev-parse', 'HEAD')
record['sourceSha256After'] = sources()
record['gitStatusAfter'] = git('status', '--porcelain=v1')
record['fixtureSha256After'] = sha(fixture) if fixture.exists() else None
record['outputs'] = [{ 'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
                     for path in [stdout_path, stderr_path]]
record_path.write_text(json.dumps(record, indent=2) + '\n')
assert record['sourceCommit'] == record['sourceCommitAfter'] and record['sourceSha256'] == record['sourceSha256After']
print(json.dumps({'phase': phase, 'exitCode': result.returncode, 'startedUtc': record['startedUtc'],
                  'completedUtc': record['completedUtc'], 'durationSeconds': record['durationSeconds'], 'record': str(record_path)}))
if phase != 'benchmark':
    print(stdout_path.read_text(), end='')
    print(stderr_path.read_text(), end='')
sys.exit(result.returncode)

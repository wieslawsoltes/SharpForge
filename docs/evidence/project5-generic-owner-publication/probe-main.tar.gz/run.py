from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
import os
import re
import signal
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path('/workspace/scratch/1692a10afba9')
PACKET = Path(__file__).resolve().parent
REPOSITORY = ROOT / 'p5-cil-generic-owners-publish'
ORCHESTRATOR = ROOT / 'cil-generic-publication-performance/paired.py'
EXPECTED_ORCHESTRATOR = 'ebc6798e2a450fd12da9819cbea40aff4b1a48beeb40c63d8fdf13df783106e9'
PINNED = {'DOTNET_ROOT': str(ROOT / 'toolchain/dotnet'),
          'DOTNET': str(ROOT / 'toolchain/dotnet/dotnet'),
          'SHARPFORGE_ORACLE_DOTNET': str(ROOT / 'toolchain/dotnet/dotnet')}
GROUPS = {'probe': ['tests/support/generic-call-fixture.js'],
          'focused': ['tests/a05-cil-generic-metadata-names.test.js', 'tests/a05-cil-async-generics.test.js',
                      'tests/a05-02-generic-calls.test.js', 'tests/a05-02-generic-dispatch.test.js',
                      'tests/a05-type-tables.test.js']}
IMPORT = re.compile(r'''(?:^|[;\n])\s*(?:import\s+(?:[^;'"()]*?\s+from\s*)?|export\s+(?:\{[^}]*\}|\*(?:\s+as\s+\w+)?)\s+from\s*)(["'])([^"']+)\1''')
DYNAMIC = re.compile(r'''\bimport\s*\(\s*(["'])([^"']+)\1''')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    with path.open('x') as file:
        json.dump(value, file, indent=2)
        file.write('\n')

def child(plan_path):
    plan = json.loads(plan_path.read_text())
    directory = Path(plan['output'])
    started = time.monotonic()
    save(directory / 'child-start.json', {'time': datetime.now(timezone.utc).isoformat(), 'command': plan['command']})
    process = subprocess.Popen(plan['command'], cwd=plan['export'], start_new_session=True)
    timed_out = False
    try:
        code = process.wait(timeout=90)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=5)
    save(directory / 'child-result.json', {'exitCode': code, 'timedOut': timed_out,
                                           'seconds': time.monotonic() - started})
    return code if code >= 0 else 1

if sys.argv[1:2] == ['--child']:
    raise SystemExit(child(Path(sys.argv[2])))
if len(sys.argv) != 3 or sys.argv[1] not in GROUPS:
    raise SystemExit('usage: run.py probe|focused EXACT_COMMIT')
GROUP, REVISION = sys.argv[1:]
assert digest(ORCHESTRATOR.read_bytes()) == EXPECTED_ORCHESTRATOR
spec = importlib.util.spec_from_file_location('pinned_export', ORCHESTRATOR)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
assert helper.revision(REPOSITORY, REVISION) == REVISION
output = PACKET / (GROUP + '-' + REVISION[:12])
output.mkdir(exist_ok=False)
result = {'sourceRevision': REVISION, 'group': GROUP, 'environment': PINNED,
          'runnerSha256': digest(Path(__file__).read_bytes()), 'exporterSha256': EXPECTED_ORCHESTRATOR}
with tempfile.TemporaryDirectory(prefix='export-', dir=output) as temporary:
    export = Path(temporary)
    entries = [*GROUPS[GROUP], 'scripts/limited.js']
    inventory = helper.export_sources(REPOSITORY, REVISION, export, entries)
    tracked_paths = {item['path'] for item in inventory['files']}
    edges, pending = {}, list(entries)
    while pending:
        name = pending.pop()
        if name in edges:
            continue
        path = export / name
        if name not in tracked_paths:
            data = helper.git(REPOSITORY, 'show', REVISION + ':' + name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            inventory['files'].append({'path': name, 'bytes': len(data), 'sha256': digest(data)})
            tracked_paths.add(name)
        dependencies = []
        for _, module in IMPORT.findall(path.read_text()) + DYNAMIC.findall(path.read_text()):
            if module.startswith('node:'):
                continue
            if module.startswith('@sharpforge/'):
                package, _, subpath = module[len('@sharpforge/'):].partition('/')
                package_dir = export / 'packages' / package
                alias = export / 'node_modules/@sharpforge' / package
                assert alias.resolve() == package_dir.resolve()
                manifest = json.loads((package_dir / 'package.json').read_text())
                exports = manifest.get('exports')
                entry = exports if isinstance(exports, str) else (exports or {}).get('./' + subpath if subpath else '.')
                target = package_dir / (entry or manifest['main'])
            elif module.startswith('.'):
                target = path.parent / module
            else:
                raise RuntimeError('Unresolved bare import: ' + module)
            dependency = str(target.resolve().relative_to(export))
            dependencies.append(dependency)
            pending.append(dependency)
        edges[name] = sorted(set(dependencies))
    if GROUP == 'probe':
        data = (PACKET / 'probe.mjs').read_bytes()
        (export / 'probe.mjs').write_bytes(data)
        inventory['files'].append({'path': 'probe.mjs', 'bytes': len(data), 'sha256': digest(data), 'origin': 'reviewed probe harness'})
        command = ['node', 'probe.mjs']
    else:
        command = ['node', '--test', '--test-concurrency=1', *GROUPS[GROUP]]
    aliases = {name: str((export / 'node_modules/@sharpforge' / name).resolve()) for name in inventory['packages']}
    helper.verify_export(export, inventory)
    save(output / 'inputs.json', {'inventory': inventory, 'graph': edges, 'aliases': aliases})
    save(output / 'child-plan.json', {'export': str(export), 'output': str(output), 'command': command})
    limiter = ['node', 'scripts/limited.js', 'python3', str(Path(__file__).resolve()), '--child', str(output / 'child-plan.json')]
    result.update(command=limiter, materializedFiles=len(inventory['files']), graphModules=len(edges), aliases=len(aliases))
    print(json.dumps({'phase': 'queued', **result}), flush=True)
    started = time.monotonic()
    with (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
        process = subprocess.run(limiter, cwd=export, env=dict(os.environ, **PINNED), stdout=stdout, stderr=stderr)
    duration = time.monotonic() - started
    child_result = json.loads((output / 'child-result.json').read_text())
    helper.verify_export(export, inventory)
    assert aliases == {name: str((export / 'node_modules/@sharpforge' / name).resolve()) for name in inventory['packages']}
    result.update(exitCode=process.returncode, child=child_result, outerSeconds=duration,
                  limiterAndStartupSeconds=duration-child_result['seconds'], sourcesAndAliasesUnchanged=True)
    raw = (output / 'stdout.log').read_bytes()
    result.update(stdoutBytes=len(raw), stdoutSha256=digest(raw), stderrBytes=(output / 'stderr.log').stat().st_size)
    result['nodeSummary'] = re.findall(r'^[#ℹ] (?:tests|suites|pass|fail|cancelled|skipped|todo|duration_ms) .+$', raw.decode(), re.M)
    save(output / 'result.json', result)
    with (output / 'qualified-source.tar.gz').open('xb') as file:
        with gzip.GzipFile(fileobj=file, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for item in sorted(inventory['files'], key=lambda item: item['path']):
                    data = (export / item['path']).read_bytes()
                    info = tarfile.TarInfo(item['path'])
                    info.size, info.mtime, info.mode = len(data), 0, 0o644
                    tar.addfile(info, io.BytesIO(data))
print(json.dumps(result), flush=True)
raise SystemExit(result['exitCode'])

import {createHash} from 'node:crypto';
import {verifyCilAssembly} from '@sharpforge/cil';
import {genericCallFixture} from './tests/support/generic-call-fixture.js';

const bytes = genericCallFixture([
  {name: 'Value', base: 'System.ValueType', fields: [{name: 'N', type: 'int'}], methods: []},
  {name: 'Program', methods: [
    {name: 'Main', body: (writer, context) => writer.op('call',
      context.methodSpec(context.methods.get('Program.Use'), ['Value'])).op('ret')},
    {name: 'Use', genericParameters: [{}], body: writer => writer.op('ret')}
  ]}
]);
console.log(JSON.stringify({fixtureSha256: createHash('sha256').update(bytes).digest('hex'),
  report: verifyCilAssembly(bytes)}, null, 2));
